import React from "react";

export default (props) => {

    const gerarIdade = () => parseInt(Math.random() * (100 - 1) * 1)
    const gerarAtivo = () => Math.random() < 0.5

    return (
        <>
            <h2> Dados do Pai </h2>
            <button onClick={() => props.chamaPai('Josefina Lima', gerarIdade(), gerarAtivo())}> Exibir Dados </button>
        </>
    )
}
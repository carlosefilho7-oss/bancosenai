import './App.css'

import ComunicacaoIndiretaPai from './componentes/ComunicacaoIndiretaPai'
import ComunicacaoDiretaPai from './componentes/ComunicacaoDiretaPai'
import Input from './componentes/formulario/Input'
import Pessoas from './componentes/Pessoas'
import NumeroAleatorio from './componentes/NumeroAleatorio'
import SituacaoAluno from './componentes/SituacaoAluno'
import Card from './componentes/Card'
import ComponenteComParametro from './componentes/ComponenteComParametro'
import SegundoComponente from './componentes/SegundoComponente'
import Primeiro from './componentes/Primeiro'

function App() {

  return (
    <>
      <Card titulo="Input Formulário" cor='#008B8B'>
        <Input 
          tipo='number'
          nome='valorUnitario' 
          classe='input'  
          etiqueta = 'informe o valor Unitário'
          />
      </Card>

      <Card titulo='Comunincação indireta' cor='#7B68EE'>
        <ComunicacaoIndiretaPai></ComunicacaoIndiretaPai>
      </Card>
    
      <Card titulo="Comunicação Direta" cor="#D2691E">
        <ComunicacaoDiretaPai nome='Maria Flor' idade={16} ativo={true}/>
      </Card>

      <Card titulo='Lista Pessoas' cor='#EEC900'>
        <Pessoas />
      </Card>

      <Card titulo='Números aleatório' cor='#548B54'>
        <NumeroAleatorio min={1} max={60} />
        <NumeroAleatorio min={1} max={60} />
        <NumeroAleatorio min={1} max={60} />
        <NumeroAleatorio min={1} max={60} />
        <NumeroAleatorio min={1} max={60} />
        <NumeroAleatorio min={1} max={60} />
      </Card>

      <Card titulo='Situação do Aluno' cor='#EE9A00'>
        <SituacaoAluno nome='Josefina Gomes' media={10} />
        <SituacaoAluno nome='Astrogildo' media={4} />
      </Card>

      <Card titulo='Componente com Parâmetro'>
        <ComponenteComParametro nome='Maria Flor' idade={48} renda={500.00} />
      </Card>

      <Card titulo='Segundo Componente' cor='#D2691E'>
        <SegundoComponente></SegundoComponente>
      </Card>

      <Card titulo='Primeiro Componente' cor='#4682B4'>
        <Primeiro />
      </Card>




    </>
  )
}

export default App

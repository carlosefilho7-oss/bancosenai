
import React, {useState} from "react";

import ComunicacaoIndiretaFilho from "./ComunicacaoIndiretaFilho";

export default (props) => {
    const [nome,setNome] = useState('Arroz')
    const [idade, setIdade] = useState(80)
    const [ativo, setAtivo] = useState(true)
    

    const  mostrarDados = (nomeParam, idadeParam, AtivoParam) => {
        setNome(nomeParam)
        setIdade(idadeParam)
        setAtivo(AtivoParam)
        console.log('Componente Pai Indireta ', nomeParam, idadeParam, AtivoParam)
    }

    return(
        <>
            <h2> Indireta Pai </h2>
            <span> {nome} </span>
            <span> {idade} </span>
            <span> {ativo ? 'Ativo': 'Inativo'} </span>
            <ComunicacaoIndiretaFilho chamaPai={mostrarDados}/>
        </>
    )
}
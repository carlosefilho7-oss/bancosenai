import React from "react"
import DadosPessoas from './../dados/dados_pessoas.js'

export default () => {

    const listaPessoas = DadosPessoas.map((elem, i)=>{
        return(
            <li key={i}>
                {elem.nome} - {elem.idade} - R$ {parseFloat(elem.renda).toFixed(2).replace('.',',')}
            </li>
        )
    })

    return (
        <ul>
            {listaPessoas}
        </ul>
    )
}
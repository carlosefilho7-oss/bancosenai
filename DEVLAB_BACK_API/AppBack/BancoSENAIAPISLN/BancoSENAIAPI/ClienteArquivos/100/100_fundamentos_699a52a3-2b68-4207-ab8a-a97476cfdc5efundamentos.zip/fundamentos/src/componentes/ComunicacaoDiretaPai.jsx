import React from "react";

import ComunicacoDiretaFilho from "./ComunicacoDiretaFilho";

export default (props) => {

    return(
        <>
            <ComunicacoDiretaFilho nome={props.nome} idade={props.idade} ativo={props.ativo}/>
        </>
    )

}